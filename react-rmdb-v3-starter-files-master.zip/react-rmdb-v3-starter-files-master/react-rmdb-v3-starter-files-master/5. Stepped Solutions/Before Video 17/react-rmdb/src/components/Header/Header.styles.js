import styled from 'styled-components';

export const Wrapper = styled.div``;

export const Content = styled.div``;

export const LogoImg = styled.img``;

export const TMDBLogoImg = styled.img``;