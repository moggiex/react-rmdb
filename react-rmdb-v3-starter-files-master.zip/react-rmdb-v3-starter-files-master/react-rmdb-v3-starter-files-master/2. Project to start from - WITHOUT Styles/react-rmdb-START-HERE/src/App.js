import React from 'react';

const App = () => <div>Start here!</div>

export default App;
