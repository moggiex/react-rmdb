import React from 'react';
import { GlobalStyle } from './GlobalStyle';

const App = () => (
  <div>
    Start here!
    <GlobalStyle />
  </div>
);

export default App;
