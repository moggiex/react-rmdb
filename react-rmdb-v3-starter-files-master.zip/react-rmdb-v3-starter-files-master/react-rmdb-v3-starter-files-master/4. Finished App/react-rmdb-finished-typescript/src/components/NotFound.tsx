import React from 'react';

const NotFound: React.FC = () => <div>NotFound</div>;

export default NotFound;